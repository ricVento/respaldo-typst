= Introducción
Este proyecto contiene la descripción gramatical de la lengua objeto de estudio.

== Metodología
Los datos fueron recolectados mediante sesiones de elicitación directa.

== Alfabeto
El idioma usa el alfabeto fonetico internacional (/AFI) con algunas modificaciones como χ qχʷ ʔɑtʃ'ɪdʒ ł ƛ qχ° æ
